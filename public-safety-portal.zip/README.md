# Public Safety Portal (Neutral Template)

A clean, accessible government‑style template inspired by public safety portals. 
**No copyrighted branding, logos, or text are included.** Use this as a base and add your own content.

## Dev
npm install
npm run dev

## Build
npm run build

## Deploy (Vercel)
Framework: Vite
Build: npm run build
Output: dist
