import React from 'react'
import { Search, Phone, FileText, MapPin, Shield, AlertTriangle, ExternalLink, ChevronRight } from 'lucide-react'

const Container = ({children}) => <div className="mx-auto max-w-6xl px-4">{children}</div>
const Card = ({children, className=""}) => <div className={`rounded-xl border bg-white p-5 shadow-sm ${className}`}>{children}</div>

export default function App() {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      {/* Header */}
      <header className="border-b bg-white">
        <Container>
          <div className="flex items-center justify-between py-4">
            <a href="#" className="flex items-center gap-3">
              <div className="h-8 w-8 rounded bg-brand"></div>
              <div>
                <div className="text-sm text-slate-500 tracking-wide uppercase">Public Safety</div>
                <div className="text-xl font-semibold">Local Police Portal</div>
              </div>
            </a>
            <nav className="hidden gap-6 md:flex">
              <a className="hover:text-brand" href="#report">Report</a>
              <a className="hover:text-brand" href="#advice">Advice</a>
              <a className="hover:text-brand" href="#contact">Contact</a>
            </nav>
          </div>
        </Container>
      </header>

      {/* Emergency banner */}
      <div className="gov-banner">
        <Container>
          <div className="flex flex-wrap items-center justify-between gap-3 py-3">
            <div className="flex items-center gap-2 font-medium"><AlertTriangle className="h-5 w-5" /> Emergency? Call 999</div>
            <a className="inline-flex items-center gap-2 rounded-md bg-brand px-3 py-2 text-white hover:bg-brand-dark" href="#contact">
              Non‑emergency 101
            </a>
          </div>
        </Container>
      </div>

      {/* Search & quick actions */}
      <Container>
        <div className="grid gap-6 py-8 md:grid-cols-3">
          <Card className="md:col-span-2">
            <label className="mb-2 block text-sm font-medium">Search information & services</label>
            <div className="flex items-center gap-2 rounded-lg border px-3 py-2">
              <Search className="h-5 w-5" />
              <input placeholder="e.g. report a crime, neighbourhood team" className="w-full bg-transparent outline-none" />
              <button className="inline-flex items-center gap-2 rounded-md bg-brand px-3 py-2 text-white hover:bg-brand-dark">Search</button>
            </div>
            <div className="mt-3 text-sm text-slate-600">Popular searches: burglary, fraud, anti-social behaviour, neighbourhood watch</div>
          </Card>
          <Card>
            <div className="flex items-start gap-3">
              <Phone className="mt-1 h-5 w-5" />
              <div>
                <div className="font-semibold">Contact us</div>
                <p className="text-slate-600">Report non‑emergencies online or by phone. For emergencies, call 999.</p>
                <div className="mt-2 flex gap-2">
                  <a className="rounded-md border px-3 py-1.5" href="#contact">Online</a>
                  <a className="rounded-md border px-3 py-1.5" href="#contact">Phone</a>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </Container>

      {/* Services */}
      <section id="report" className="py-8">
        <Container>
          <h2 className="mb-4 text-2xl font-semibold">Report & Services</h2>
          <div className="grid gap-4 md:grid-cols-3">
            {[
              {icon: <FileText className="h-5 w-5" />, title: 'Report a crime', desc: 'Start an online report for non‑emergencies.'},
              {icon: <Shield className="h-5 w-5" />, title: 'Advice & safety', desc: 'Guides on staying safe at home and online.'},
              {icon: <MapPin className="h-5 w-5" />, title: 'Neighbourhoods', desc: 'Find your local policing team and meetings.'},
            ].map((s, i) => (
              <Card key={i}>
                <div className="mb-2 flex items-center gap-2">{s.icon}<div className="font-semibold">{s.title}</div></div>
                <p className="text-slate-600">{s.desc}</p>
                <a className="mt-3 inline-flex items-center gap-1 text-brand underline" href="#">
                  Learn more <ChevronRight className="h-4 w-4" />
                </a>
              </Card>
            ))}
          </div>
        </Container>
      </section>

      {/* News */}
      <section className="bg-white py-8">
        <Container>
          <h2 className="mb-4 text-2xl font-semibold">News & Updates</h2>
          <div className="grid gap-4 md:grid-cols-3">
            {[1,2,3].map((n) => (
              <Card key={n}>
                <div className="text-sm text-slate-500">12 Oct 2025</div>
                <div className="mt-1 font-semibold">Community operation results</div>
                <p className="mt-1 text-slate-600">Summary of recent activity and outcomes across local wards.</p>
                <a className="mt-3 inline-flex items-center gap-1 text-brand underline" href="#"><ExternalLink className="h-4 w-4" /> Read update</a>
              </Card>
            ))}
          </div>
        </Container>
      </section>

      {/* Footer */}
      <footer id="contact" className="border-t bg-white py-8">
        <Container>
          <div className="grid gap-6 md:grid-cols-3">
            <div>
              <div className="text-lg font-semibold">Contact</div>
              <ul className="mt-2 space-y-1 text-slate-700">
                <li>Emergency: 999</li>
                <li>Non‑emergency: 101</li>
                <li>Email: contact@example.gov</li>
              </ul>
            </div>
            <div>
              <div className="text-lg font-semibold">Quick links</div>
              <ul className="mt-2 space-y-1">
                <li><a className="underline" href="#">Make a report</a></li>
                <li><a className="underline" href="#">Data protection</a></li>
                <li><a className="underline" href="#">Accessibility</a></li>
              </ul>
            </div>
            <div>
              <div className="text-lg font-semibold">About this site</div>
              <p className="mt-2 text-slate-600">This is a generic, unbranded template for a public‑safety portal. Replace placeholders with your organisation’s content and branding.</p>
            </div>
          </div>
          <div className="mt-6 text-sm text-slate-500">© 2025 Public Safety Portal</div>
        </Container>
      </footer>
    </div>
  )
}
